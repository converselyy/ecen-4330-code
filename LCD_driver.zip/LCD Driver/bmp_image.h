# define PROGMEM
# define pgm_read_byte(addr) (*(const unsigned char *)(addr))
# define pgm_read_word(addr) (*(const unsigned int *)(addr))

//static const unsigned int bmp_image[] PROGMEM = {
//
//};


